package com.example.a15_igniteform

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        submitBTN.setOnClickListener {
        var gender = genderRB.checkedRadioButtonId
        var gen:String = ""
            when(gender){
            R.id.maleRB -> gen = "male"
            R.id.femaleRB -> gen = "female"
            else -> gen = "not"
        }
            var events = ""
            if(code.isChecked){ events = events + "code"}
            if(web.isChecked){events = events + "web"}
            if(game.isChecked){events = events +"game"}

            if(nameET.text.toString() =="" || idET.text.toString() == "" || gen == "not" || events == "")
            {
                Toast.makeText(this, "Enter All", Toast.LENGTH_LONG).show()

            }
            else
            {
                Toast.makeText(this, nameET.text.toString()+idET.text.toString()+gen+events, Toast.LENGTH_LONG).show()
            }
        }
    }
}